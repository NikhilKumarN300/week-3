// Write a program to print your Name, Father's Name and Mailing Address in different lines

public class Exercise1 {
  public static void main(String args[])
  {
    System.out.println("Nikhil Kumar N");
    System.out.println("father =Narayanaswamy M");
    System.out.println("email=nikhilnayak456@gmail.com");
    
  }



} 