// Write a program to print your name

public class Sample1 {

	public static void main(String args[]) {

	System.out.println("Nikhil Kumar N");
	
	}
}